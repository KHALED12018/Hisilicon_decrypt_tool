import tkinter as tk
from tkinter import filedialog
from OpenSSL.crypto import FILETYPE_PEM, load_privatekey, load_certificate

def load_rsa_key():
    rsa_key_path = filedialog.askopenfilename(title="Select RSA Key", filetypes=[("Text Files", "*.txt")])
    with open(rsa_key_path, "r") as file:
        rsa_key_data = file.read()
        rsa_key_lines = rsa_key_data.strip().split("\n")
        n = int(rsa_key_lines[0].split("=")[1], 16)
        e = int(rsa_key_lines[1].split("=")[1], 16)
        d = int(rsa_key_lines[2].split("=")[1], 16)
        p = int(rsa_key_lines[3].split("=")[1], 16)
        q = int(rsa_key_lines[4].split("=")[1], 16)
        dp = int(rsa_key_lines[5].split("=")[1], 16)
        dq = int(rsa_key_lines[6].split("=")[1], 16)
        qinv = int(rsa_key_lines[7].split("=")[1], 16)
    private_key = load_privatekey(FILETYPE_PEM, rsa_key_data.encode())
    return private_key

def load_certificate():
    certificate_path = filedialog.askopenfilename(title="Select Certificate", filetypes=[("X.509 Certificate", "*.x509.pem")])
    certificate_file = open(certificate_path, "rb").read()
    return load_certificate(FILETYPE_PEM, certificate_file)

def encrypt_file():
    file_path = filedialog.askopenfilename(title="Select File to Encrypt", filetypes=[("All Files", "*.*")])
    output_file = filedialog.asksaveasfilename(title="Save Encrypted File", filetypes=[("Encrypted File", "*.enc")])
    data = open(file_path, "rb").read()
    encrypted_data = certificate.encrypt(data, padding=True)
    with open(output_file, "wb") as file:
        file.write(encrypted_data)
    print("File encrypted successfully!")

def decrypt_file():
    file_path = filedialog.askopenfilename(title="Select Encrypted File", filetypes=[("Encrypted File", "*.enc")])
    output_file = filedialog.asksaveasfilename(title="Save Decrypted File", filetypes=[("Decrypted File", "*.*")])
    encrypted_data = open(file_path, "rb").read()
    decrypted_data = private_key.decrypt(encrypted_data, padding=True)
    with open(output_file, "wb") as file:
        file.write(decrypted_data)
    print("File decrypted successfully!")

window = tk.Tk()
window.title("Encryption/Decryption Application")
window.geometry("400x200")

private_key = None
certificate = None

load_rsa_key_btn = tk.Button(window, text="Load RSA Key", command=lambda: private_key = load_rsa_key())
load_rsa_key_btn.pack()

load_certificate_btn = tk.Button(window, text="Load Certificate", command=lambda: certificate = load_certificate())
load_certificate_btn.pack()

encrypt_btn = tk.Button(window, text="Encrypt File", command=encrypt_file)
encrypt_btn.pack()

decrypt_btn = tk.Button(window, text="Decrypt File", command=decrypt_file)
decrypt_btn.pack()

window.mainloop()
